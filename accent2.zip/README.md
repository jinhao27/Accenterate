# accenterate
Accenterate: hack for NSBE Hacks. Authors: Amardeep Singh, Aung Khant Min, Jinhao Xie, Lucas Wang. Web app that identifies accents from a voice files
